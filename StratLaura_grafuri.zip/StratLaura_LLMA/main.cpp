#include <fstream>
using namespace std;

ifstream fin("text.in");
ofstream fout("text.out");

int main()
{
    int n;
    int m[100][100];
    int cont, p, q;
    fin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            m[i][j]=0;
    for(int i=1;i<=n;i++)
    {
        fin>>cont;
        for(int j=1;j<=cont;j++)
        {
            fin>>p;
            m[i][p]=1;
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            fout<<m[i][j]<<" ";
        fout<<endl;
    }
}
